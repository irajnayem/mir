<?php
$dm = 'https://auto.likethue-vn.ml'; // không có / ở cuối

$host = "localhost";
$username = "hacksubg_2";
$password = "1232123aBc";
$dbname = "hacksubg_2";
$connection = mysql_connect($host,$username,$password);
if (!$connection)
{
die('Không Thể Kết Nối Tới CSDL => Config CSDL Sai Rồi');
}
mysql_select_db($dbname) or die('Không Kết Nối Được Tới Database => Config Sai Database');
mysql_query("SET NAMES utf8");
?>